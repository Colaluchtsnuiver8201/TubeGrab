import os
from pytube import YouTube

print("  _______      _             _____              _     ")
print(" |__   __|    | |           / ____|            | |    ")
print("    | | _   _ | |__    ___ | |  __  _ __  __ _ | |__  ")
print("    | || | | || '_ \  / _ \| | |_ || '__|/ _` || '_ \ ")
print("    | || |_| || |_) ||  __/| |__| || |  | (_| || |_) |")
print("    |_| \__,_||_.__/  \___| \_____||_|   \__,_||_.__/ ")
print("     MADE BY COLA.                                    ")

# Prompt for the YouTube video URL
video_url = input("Enter the YouTube video URL: ")

# Set the download folder path
download_folder = os.path.join(os.path.expanduser("~"), "Downloads", "YT-videos")

# Create the download folder if it doesn't exist
os.makedirs(download_folder, exist_ok=True)

# Download the YouTube video
yt = YouTube(video_url)
video = yt.streams.get_highest_resolution()
video.download(download_folder)

print("Video downloaded successfully!")

# Additional code modifications can be made here
