import os
from pytube import YouTube

print("Tubegrab: MADE BY COLA.")

# Prompt for the YouTube video URL
video_url = input("Enter the YouTube video URL: ")

# Set the download folder path
download_folder = os.path.join(os.path.expanduser("~"), "Downloads", "TubeGrab", "Videos")

# Create the download folder if it doesn't exist
os.makedirs(download_folder, exist_ok=True)

# Download the YouTube video
yt = YouTube(video_url)
video = yt.streams.get_highest_resolution()
video.download(download_folder)

print("Video downloaded successfully!")

# Keep the terminal window open until the user presses Enter
input("Press Enter to exit.")
